/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.6.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Avalanche/mainwindow.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.6.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "on_pushButton_4_clicked",
    "",
    "on_pushButton_5_clicked",
    "on_pushButton_3_clicked",
    "on_pushButton_6_clicked",
    "on_pushButton_8_clicked",
    "on_pushButton_9_clicked",
    "on_pushButton_12_clicked",
    "on_pushButton_13_clicked",
    "on_pushButton_7_clicked",
    "on_pushButton_14_clicked",
    "on_tableView_pressed",
    "QModelIndex",
    "index",
    "on_checkBox_toggled",
    "checked",
    "on_checkBox_2_toggled",
    "on_pushButton_15_clicked",
    "on_pushButton_11_clicked",
    "on_pushButton_16_clicked",
    "on_pushButton_17_clicked",
    "on_checkBox_5_stateChanged",
    "arg1",
    "on_checkBox_3_stateChanged",
    "on_checkBox_4_stateChanged"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {
    uint offsetsAndSizes[52];
    char stringdata0[11];
    char stringdata1[24];
    char stringdata2[1];
    char stringdata3[24];
    char stringdata4[24];
    char stringdata5[24];
    char stringdata6[24];
    char stringdata7[24];
    char stringdata8[25];
    char stringdata9[25];
    char stringdata10[24];
    char stringdata11[25];
    char stringdata12[21];
    char stringdata13[12];
    char stringdata14[6];
    char stringdata15[20];
    char stringdata16[8];
    char stringdata17[22];
    char stringdata18[25];
    char stringdata19[25];
    char stringdata20[25];
    char stringdata21[25];
    char stringdata22[27];
    char stringdata23[5];
    char stringdata24[27];
    char stringdata25[27];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSMainWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSMainWindowENDCLASS_t qt_meta_stringdata_CLASSMainWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 10),  // "MainWindow"
        QT_MOC_LITERAL(11, 23),  // "on_pushButton_4_clicked"
        QT_MOC_LITERAL(35, 0),  // ""
        QT_MOC_LITERAL(36, 23),  // "on_pushButton_5_clicked"
        QT_MOC_LITERAL(60, 23),  // "on_pushButton_3_clicked"
        QT_MOC_LITERAL(84, 23),  // "on_pushButton_6_clicked"
        QT_MOC_LITERAL(108, 23),  // "on_pushButton_8_clicked"
        QT_MOC_LITERAL(132, 23),  // "on_pushButton_9_clicked"
        QT_MOC_LITERAL(156, 24),  // "on_pushButton_12_clicked"
        QT_MOC_LITERAL(181, 24),  // "on_pushButton_13_clicked"
        QT_MOC_LITERAL(206, 23),  // "on_pushButton_7_clicked"
        QT_MOC_LITERAL(230, 24),  // "on_pushButton_14_clicked"
        QT_MOC_LITERAL(255, 20),  // "on_tableView_pressed"
        QT_MOC_LITERAL(276, 11),  // "QModelIndex"
        QT_MOC_LITERAL(288, 5),  // "index"
        QT_MOC_LITERAL(294, 19),  // "on_checkBox_toggled"
        QT_MOC_LITERAL(314, 7),  // "checked"
        QT_MOC_LITERAL(322, 21),  // "on_checkBox_2_toggled"
        QT_MOC_LITERAL(344, 24),  // "on_pushButton_15_clicked"
        QT_MOC_LITERAL(369, 24),  // "on_pushButton_11_clicked"
        QT_MOC_LITERAL(394, 24),  // "on_pushButton_16_clicked"
        QT_MOC_LITERAL(419, 24),  // "on_pushButton_17_clicked"
        QT_MOC_LITERAL(444, 26),  // "on_checkBox_5_stateChanged"
        QT_MOC_LITERAL(471, 4),  // "arg1"
        QT_MOC_LITERAL(476, 26),  // "on_checkBox_3_stateChanged"
        QT_MOC_LITERAL(503, 26)   // "on_checkBox_4_stateChanged"
    },
    "MainWindow",
    "on_pushButton_4_clicked",
    "",
    "on_pushButton_5_clicked",
    "on_pushButton_3_clicked",
    "on_pushButton_6_clicked",
    "on_pushButton_8_clicked",
    "on_pushButton_9_clicked",
    "on_pushButton_12_clicked",
    "on_pushButton_13_clicked",
    "on_pushButton_7_clicked",
    "on_pushButton_14_clicked",
    "on_tableView_pressed",
    "QModelIndex",
    "index",
    "on_checkBox_toggled",
    "checked",
    "on_checkBox_2_toggled",
    "on_pushButton_15_clicked",
    "on_pushButton_11_clicked",
    "on_pushButton_16_clicked",
    "on_pushButton_17_clicked",
    "on_checkBox_5_stateChanged",
    "arg1",
    "on_checkBox_3_stateChanged",
    "on_checkBox_4_stateChanged"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  134,    2, 0x08,    1 /* Private */,
       3,    0,  135,    2, 0x08,    2 /* Private */,
       4,    0,  136,    2, 0x08,    3 /* Private */,
       5,    0,  137,    2, 0x08,    4 /* Private */,
       6,    0,  138,    2, 0x08,    5 /* Private */,
       7,    0,  139,    2, 0x08,    6 /* Private */,
       8,    0,  140,    2, 0x08,    7 /* Private */,
       9,    0,  141,    2, 0x08,    8 /* Private */,
      10,    0,  142,    2, 0x08,    9 /* Private */,
      11,    0,  143,    2, 0x08,   10 /* Private */,
      12,    1,  144,    2, 0x08,   11 /* Private */,
      15,    1,  147,    2, 0x08,   13 /* Private */,
      17,    1,  150,    2, 0x08,   15 /* Private */,
      18,    0,  153,    2, 0x08,   17 /* Private */,
      19,    0,  154,    2, 0x08,   18 /* Private */,
      20,    0,  155,    2, 0x08,   19 /* Private */,
      21,    0,  156,    2, 0x08,   20 /* Private */,
      22,    1,  157,    2, 0x08,   21 /* Private */,
      24,    1,  160,    2, 0x08,   23 /* Private */,
      25,    1,  163,    2, 0x08,   25 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 13,   14,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::Int,   23,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'on_pushButton_4_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_5_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_3_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_6_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_8_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_9_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_12_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_13_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_7_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_14_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableView_pressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_checkBox_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_checkBox_2_toggled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'on_pushButton_15_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_11_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_16_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_17_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_checkBox_5_stateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_checkBox_3_stateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_checkBox_4_stateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_pushButton_4_clicked(); break;
        case 1: _t->on_pushButton_5_clicked(); break;
        case 2: _t->on_pushButton_3_clicked(); break;
        case 3: _t->on_pushButton_6_clicked(); break;
        case 4: _t->on_pushButton_8_clicked(); break;
        case 5: _t->on_pushButton_9_clicked(); break;
        case 6: _t->on_pushButton_12_clicked(); break;
        case 7: _t->on_pushButton_13_clicked(); break;
        case 8: _t->on_pushButton_7_clicked(); break;
        case 9: _t->on_pushButton_14_clicked(); break;
        case 10: _t->on_tableView_pressed((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 11: _t->on_checkBox_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 12: _t->on_checkBox_2_toggled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 13: _t->on_pushButton_15_clicked(); break;
        case 14: _t->on_pushButton_11_clicked(); break;
        case 15: _t->on_pushButton_16_clicked(); break;
        case 16: _t->on_pushButton_17_clicked(); break;
        case 17: _t->on_checkBox_5_stateChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 18: _t->on_checkBox_3_stateChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 19: _t->on_checkBox_4_stateChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 20;
    }
    return _id;
}
QT_WARNING_POP
